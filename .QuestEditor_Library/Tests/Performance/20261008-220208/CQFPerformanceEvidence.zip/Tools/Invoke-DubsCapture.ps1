param(
    [ValidateSet('Snapshot', 'Capture', 'Stop', 'Install', 'Uninstall', 'Scenario', 'Verify', 'VerifyTargets', 'VerifyCqf', 'Tuning', 'Restore')]
    [string]$Action = 'Snapshot',
    [ValidateSet('Tick', 'Update')]
    [string]$Cycle = 'Tick',
    [ValidateRange(1, 300)]
    [int]$Seconds = 20,
    [ValidateRange(0, 60)]
    [int]$WarmupSeconds = 3,
    [string[]]$Methods,
    [string]$ModRoot = 'D:\Game\Steam\steamapps\common\RimWorld\Mods\CQF',
    [string]$DubsAssembly = 'D:\Game\Steam\steamapps\workshop\content\294100\2038874626\1.6\Assemblies\PerformanceAnalyzer.dll',
    [string]$SaveDataPath = (Join-Path $env:USERPROFILE 'AppData\LocalLow\Ludeon Studios\RimWorld by Ludeon Studios'),
    [string]$OutputDirectory = (Join-Path $PSScriptRoot 'Results'),
    [ValidateRange(1, 60)]
    [int]$TimeoutSeconds = 15,
    [string]$Kind = 'FH_Fingerspike',
    [string]$Mode = 'HCF_GroupWorkMode_Attack',
    [ValidateRange(0, 500)]
    [int]$Count = 100,
    [ValidateRange(1, 100)]
    [int]$GroupCount = 10,
    [bool]$ShowTargets = $true,
    [string]$GroupType = 'HiveCreatureFramework.UnitGroup',
    [ValidateRange(0, 10)]
    [int]$ProbeCallsPerTick = 0,
    [bool]$BaselineGroupLayout = $false,
    [bool]$CompareProbe = $false,
    [ValidateRange(0, 60)] [int]$HiveCount = 0,
    [bool]$StoreUnits = $false,
    [bool]$InjuredUnits = $false,
    [bool]$HealUnits = $true,
    [bool]$DepletedMaintenance = $false,
    [ValidateRange(0, 1000)] [int]$ProgressPerHive = 0,
    [ValidateRange(0, 500)] [int]$HaulStacks = 0,
    [bool]$DeveloperMode = $false,
    [bool]$DeveloperLogs = $false,
    [bool]$BaselineTargetSearch = $false,
    [bool]$BaselineCqfTick = $false
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$bridgeDirectory = Join-Path $SaveDataPath 'CQF-DubsBridge'
$targetModRoot = [IO.Path]::GetFullPath($ModRoot)
if (-not (Test-Path -LiteralPath (Join-Path $targetModRoot 'About\About.xml'))) { throw "Invalid host mod directory: $targetModRoot" }
$installedDll = Join-Path $targetModRoot '1.6\Assemblies\ZZ_CQF.PerformanceBridge.dll'

if ($Action -in @('Install', 'Uninstall')) {
    if (Get-Process -Name RimWorldWin64 -ErrorAction SilentlyContinue) {
        throw 'Close RimWorld before installing or uninstalling the bridge.'
    }
    if ($Action -eq 'Install') {
        $project = Join-Path $PSScriptRoot 'Bridge\HCF.DubsBridge.csproj'
        $hcfAssembly = 'D:\Game\Steam\steamapps\common\RimWorld\Mods\巢群生物框架\1.6\Assemblies\net472\HiveCreatureFramework.dll'
        if (-not (Test-Path -LiteralPath $hcfAssembly)) { throw "The HCF adapter requires $hcfAssembly" }
        if (-not (Test-Path -LiteralPath $DubsAssembly)) { throw "Dubs assembly not found: $DubsAssembly" }
        & dotnet build $project -c Release --nologo "-p:HcfAssembly=$hcfAssembly" "-p:DubsAssembly=$DubsAssembly" "-p:CqfAssembly=$(Join-Path $targetModRoot '1.6\Assemblies\net48\QuestEditor_Library.dll')"
        if ($LASTEXITCODE -ne 0) { throw 'Bridge build failed.' }
        Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Bridge\bin\Release\net48\CQF.PerformanceBridge.dll') -Destination $installedDll -Force
        Write-Output $installedDll
    } elseif (Test-Path -LiteralPath $installedDll) {
        Remove-Item -LiteralPath $installedDll
        Write-Output $installedDll
    }
    return
}

if (-not (Get-Process -Name RimWorldWin64 -ErrorAction SilentlyContinue)) {
    throw 'RimWorld is not running. Install the bridge, start the game, and load a map.'
}
if (-not (Test-Path -LiteralPath $installedDll)) {
    throw 'CQF.PerformanceBridge.dll is not installed. Use -Action Install while RimWorld is closed.'
}

if (-not $Methods) {
    $Methods = if ($Cycle -eq 'Tick') {
        @(
            'HiveCreatureFramework.UnitComp:CompTick',
            'HiveCreatureFramework.MapComponent_Unit:MapComponentTick',
            'HiveCreatureFramework.CompHiveContainer:CompTick',
            'HiveCreatureFramework.CompProgressHolder:CompTickInterval',
            'HiveCreatureFramework.ThinkNode_GroupAcquireAttackTarget:TryIssueJobPackage',
            'HiveCreatureFramework.JobGiver_UnitCombat:TryGiveJob',
            'HiveCreatureFramework.JobGiver_Unit_DoWorkGiver:TryIssueJobPackage'
        )
    } else {
        @('HiveCreatureFramework.GameComponent_UnitGroup:GameComponentUpdate')
    }
}

function Send-DubsRequest {
    param([string]$Command)
    $id = [guid]::NewGuid().ToString('N')
    $request = @{ Id = $id; Action = $Command; Cycle = $Cycle; Methods = @($Methods); Kind = $Kind; Mode = $Mode; Count = $Count; GroupCount = $GroupCount; ShowTargets = $ShowTargets; GroupType = $GroupType; ProbeCallsPerTick = $ProbeCallsPerTick; BaselineGroupLayout = $BaselineGroupLayout; CompareProbe = $CompareProbe }
    $request.HiveCount = $HiveCount
    $request.StoreUnits = $StoreUnits
    $request.InjuredUnits = $InjuredUnits
    $request.HealUnits = $HealUnits
    $request.DepletedMaintenance = $DepletedMaintenance
    $request.ProgressPerHive = $ProgressPerHive
    $request.HaulStacks = $HaulStacks
    $request.DeveloperMode = $DeveloperMode
    $request.DeveloperLogs = $DeveloperLogs
    $request.BaselineTargetSearch = $BaselineTargetSearch
    $request.BaselineCqfTick = $BaselineCqfTick
    $requestPath = Join-Path $bridgeDirectory 'request.json'
    $temporaryPath = Join-Path $bridgeDirectory "$id.tmp"
    if (Test-Path -LiteralPath $requestPath) { throw 'A request is already pending; inspect CQF-DubsBridge/request.json and Player.log.' }
    [IO.File]::WriteAllText($temporaryPath, ($request | ConvertTo-Json -Depth 4), [Text.UTF8Encoding]::new($false))
    [IO.File]::Move($temporaryPath, $requestPath)
    $timer = [Diagnostics.Stopwatch]::StartNew()
    $responsePath = Join-Path $bridgeDirectory 'response.json'
    while ($timer.Elapsed.TotalSeconds -lt $TimeoutSeconds) {
        $reader = $null
        try {
            $stream = [IO.File]::Open($responsePath, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete)
            $reader = [IO.StreamReader]::new($stream, [Text.Encoding]::UTF8)
        } catch [IO.FileNotFoundException] {
            Start-Sleep -Milliseconds 200
            continue
        } catch [IO.IOException] {
            $ioError = $_.Exception
            while ($ioError.InnerException -and $ioError -isnot [IO.IOException]) { $ioError = $ioError.InnerException }
            if (($ioError.HResult -band 0xFFFF) -notin @(32, 33)) { throw }
            Write-Warning 'Dubs response has a temporary file-sharing conflict; retrying within the request timeout.'
            Start-Sleep -Milliseconds 200
            continue
        }
        try {
            $response = $reader.ReadToEnd() | ConvertFrom-Json
            if ($response.Id -eq $id) {
                if ($response.Error) { throw $response.Error }
                return $response
            }
        } finally {
            $reader.Dispose()
        }
        Start-Sleep -Milliseconds 200
    }
    throw "Dubs request '$Command' timed out. A map must be loaded; check Player.log. Pending request: $requestPath"
}

$mutex = [Threading.Mutex]::new($false, 'Local\CQF.DubsReader')
$ownsMutex = $false
$started = $false
try {
    $ownsMutex = $mutex.WaitOne(0)
    if (-not $ownsMutex) { throw 'Another DubsReader script is active.' }
    New-Item -ItemType Directory -Path $bridgeDirectory -Force | Out-Null
    if ($Action -eq 'Stop') { Send-DubsRequest 'stop'; return }
    if ($Action -eq 'Scenario') { Send-DubsRequest 'scenario'; return }
    if ($Action -eq 'Verify') { Send-DubsRequest 'verify'; return }
    if ($Action -eq 'VerifyTargets') { Send-DubsRequest 'verifyTargets'; return }
    if ($Action -eq 'VerifyCqf') { Send-DubsRequest 'verifyCqf'; return }
    if ($Action -eq 'Tuning') { Send-DubsRequest 'tuning'; return }
    if ($Action -eq 'Restore') { Send-DubsRequest 'restore'; return }
    if ($Action -eq 'Capture') {
        Send-DubsRequest 'start' | Out-Null
        $started = $true
        if ($WarmupSeconds -gt 0) { Start-Sleep -Seconds $WarmupSeconds }
        $begin = Send-DubsRequest 'reset'
        Write-Host "Dubs capture: $Cycle, $Seconds seconds, $($begin.SpawnedHcfUnits) spawned HCF units."
        Start-Sleep -Seconds $Seconds
    }
    $snapshot = Send-DubsRequest 'snapshot'
    if (-not $snapshot.Profiling -or $snapshot.Paused) { throw 'Dubs is not actively profiling; the exported data would be stale.' }
    if (@($snapshot.Rows).Count -eq 0) { throw 'Dubs returned no rows. The selected methods were not called, or the game is paused.' }
    if ($Action -eq 'Capture') {
        $snapshot | Add-Member -NotePropertyMembers @{
            RequestedSeconds = $Seconds
            CaptureStartTicks = $begin.TicksGame
            CaptureStartFrames = $begin.Frames
            CapturedTicksDelta = $snapshot.TicksGame - $begin.TicksGame
            CapturedFramesDelta = $snapshot.Frames - $begin.Frames
            CaptureStartStoredUnits = $begin.StoredUnits
            CaptureStartInjuredUnits = $begin.InjuredUnits
        }
    }
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    $stem = Join-Path $OutputDirectory ((Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + $Cycle + '-' + $snapshot.Id.Substring(0, 6))
    $snapshot | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$stem.json" -Encoding utf8NoBOM
    $snapshot.Rows | Export-Csv -LiteralPath "$stem.csv" -NoTypeInformation -Encoding utf8NoBOM
    $snapshot.Rows | Select-Object -First 20 Method, AverageMs, MaxMs, Calls, AveragePerCallMs | Format-Table -AutoSize
    if ($Action -eq 'Capture') {
        Write-Host "Tick delta: $($snapshot.TicksGame - $begin.TicksGame); frame delta: $($snapshot.Frames - $begin.Frames); Dubs cycles: $($snapshot.Entries)."
        if ($snapshot.TicksGame -eq $begin.TicksGame -and $Cycle -eq 'Tick') { throw 'No game ticks advanced during the capture.' }
    }
    if ($snapshot.Entries -ge 2000) { Write-Host 'Dubs retains only the latest 2,000 cycles; this export is a rolling window.' }
    Write-Host "JSON: $stem.json"
    Write-Host "CSV:  $stem.csv"
} finally {
    try {
        if ($started) { Send-DubsRequest 'stop' | Out-Null }
    } finally {
        if ($ownsMutex) { $mutex.ReleaseMutex() }
        $mutex.Dispose()
    }
}
