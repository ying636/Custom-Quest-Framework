using System.Runtime.Serialization;

namespace CQF.PerformanceBridge;

[DataContract]
public sealed class DubsTargetVerification
{
    [DataMember] public int SearchCases { get; set; }
    [DataMember] public int IssueCases { get; set; }
    [DataMember] public int SelectedTargets { get; set; }
    [DataMember] public int SettingsCases { get; set; }
    [DataMember] public string[] CaseNames { get; set; }
    [DataMember] public string[] AttackTargetFinderPatchOwners { get; set; }
}
