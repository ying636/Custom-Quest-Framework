using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization.Json;
using Analyzer;
using Analyzer.Profiling;
using HarmonyLib;
using UnityEngine;
using Verse;
using DubsAnalyzer = Analyzer.Profiling.Analyzer;

namespace CQF.PerformanceBridge;

public sealed class GameComponent_DubsReader : GameComponent
{
    public GameComponent_DubsReader(Game game)
    {
    }

    public override void GameComponentTick()
    {
        this.scenario.Tick();
    }

    public void Poll()
    {
        if (Time.realtimeSinceStartup < this.nextPoll)
        {
            return;
        }
        this.nextPoll = Time.realtimeSinceStartup + 0.5f;
        string directory = Path.Combine(GenFilePaths.SaveDataFolderPath, "CQF-DubsBridge");
        string requestPath = Path.Combine(directory, "request.json");
        if (!File.Exists(requestPath))
        {
            return;
        }

        DubsRequest request = null;
        try
        {
            using (FileStream stream = File.OpenRead(requestPath))
            {
                request = (DubsRequest)new DataContractJsonSerializer(typeof(DubsRequest)).ReadObject(stream);
            }
            File.Delete(requestPath);
            if (string.IsNullOrEmpty(request?.Id))
            {
                throw new InvalidDataException("Missing request Id.");
            }
            if (request.Id == this.lastRequestId)
            {
                return;
            }
            this.lastRequestId = request.Id;
            switch (request.Action)
            {
                case "start": this.Start(request); break;
                case "reset": GUIController.ResetProfilers(); break;
                case "snapshot": break;
                case "stop": this.Stop(); break;
                case "scenario": this.scenario.Configure(request); break;
                case "verify": this.scenario.Verify(); break;
                case "verifyTargets": this.scenario.VerifyTargets(); break;
                case "tuning": this.scenario.HiveScenario.ApplyControls(request); CqfTickBaseline.SetEnabled(request.BaselineCqfTick); break;
                case "verifyCqf": CqfTickChecks.Run(); break;
                case "restore": CqfTickBaseline.SetEnabled(false); this.scenario.HiveScenario.RestorePreferences(); break;
                default: throw new InvalidDataException("Unknown action: " + request.Action);
            }
            this.WriteSnapshot(directory, this.Snapshot(request.Id));
        }
        catch (Exception error)
        {
            if (request?.Id == null)
            {
                this.lastRequestId = "invalid";
            }
            Log.Error("HCF_DubsBridge_Error: " + error);
            this.WriteSnapshot(directory, new DubsSnapshot { Id = request?.Id, Error = error.ToString() });
        }
    }

    private void Start(DubsRequest request)
    {
        if (DubsAnalyzer.CurrentlyCleaningUp || this.ownedEntry != null)
        {
            throw new InvalidOperationException("Dubs cleanup or another bridge capture is active.");
        }
        if (request.Methods == null || request.Methods.Length == 0)
        {
            throw new InvalidDataException("Methods is empty.");
        }
        Category category = request.Cycle == "Tick" ? Category.Tick
            : request.Cycle == "Update" ? Category.Update
            : throw new InvalidDataException("Cycle must be Tick or Update.");
        HashSet<MethodInfo> methods = new HashSet<MethodInfo>();
        foreach (string signature in request.Methods)
        {
            int separator = signature.LastIndexOf(':');
            if (separator <= 0)
            {
                throw new InvalidDataException("Expected Type:Method: " + signature);
            }
            string typeName = signature.Substring(0, separator);
            Type type = AppDomain.CurrentDomain.GetAssemblies()
                .Select(assembly => assembly.GetType(typeName, false)).FirstOrDefault(value => value != null)
                ?? throw new TypeLoadException(typeName);
            MethodInfo[] candidates = type.GetMethods(BindingFlags.Public | BindingFlags.NonPublic
                | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly)
                .Where(method => method.Name == signature.Substring(separator + 1)).ToArray();
            if (candidates.Length != 1 || candidates[0].ContainsGenericParameters
                || candidates[0].GetMethodBody() == null)
            {
                throw new MissingMethodException("Expected one non-generic method with a body: " + signature);
            }
            methods.Add(candidates[0]);
        }
        foreach (MethodInfo method in methods)
        {
            if (MethodTransplanting.typeInfo.ContainsKey(method))
            {
                throw new InvalidOperationException("Method already belongs to another Dubs entry. Close Dubs and wait for cleanup before capture: " + method);
            }
        }
        if (Window_Analyzer.firstOpen)
        {
            Window_Analyzer.LoadEntries();
            Window_Analyzer.firstOpen = false;
        }
        if (!Modbase.isPatched)
        {
            Modbase.Harmony.Patch(typeof(Root_Play).GetMethod("Update", BindingFlags.Public | BindingFlags.Instance),
                new HarmonyMethod(typeof(H_RootUpdate), "Prefix"), new HarmonyMethod(typeof(H_RootUpdate), "Postfix"));
            Type tickPatch = typeof(Modbase).Assembly.GetType("Analyzer.Profiling.H_DoSingleTickUpdate", true);
            Modbase.Harmony.Patch(typeof(TickManager).GetMethod("DoSingleTick", BindingFlags.Public | BindingFlags.Instance),
                new HarmonyMethod(tickPatch, "Prefix"), new HarmonyMethod(tickPatch, "Postfix"));
            Modbase.isPatched = true;
        }
        this.previousEntry = GUIController.CurrentEntry?.name;
        this.previousPaused = DubsAnalyzer.CurrentlyPaused;
        FieldInfo profilingField = typeof(DubsAnalyzer).GetField("currentlyProfiling", BindingFlags.NonPublic | BindingFlags.Static)
            ?? throw new MissingFieldException(typeof(DubsAnalyzer).FullName, "currentlyProfiling");
        this.previousProfiling = (bool)profilingField.GetValue(null);
        this.previousDisableCleanup = Settings.disableCleanup;
        this.previousDisableThreading = Settings.disableThreadedPatching;
        this.previousVerboseLogging = Settings.verboseLogging;
        Settings.disableCleanup = true;
        Settings.disableThreadedPatching = true;
        Settings.verboseLogging = true;
        this.ownedEntry = "HCFDubs" + Guid.NewGuid().ToString("N");
        this.ownedMethods = methods;
        try
        {
            this.ownedType = DynamicTypeBuilder.CreateType(this.ownedEntry, methods);
            GUIController.types.Add(this.ownedEntry, this.ownedType);
            GUIController.AddEntry(this.ownedEntry, category);
            DubsAnalyzer.CurrentlyPaused = false;
            DubsAnalyzer.BeginProfiling();
            GUIController.SwapToEntry(this.ownedEntry);
            if (!GUIController.CurrentEntry.isPatched)
            {
                throw new InvalidOperationException("Dubs failed to patch the requested methods; see Player.log.");
            }
            MethodInfo transpiler = typeof(MethodTransplanting).GetMethod("Transpiler");
            foreach (MethodInfo method in methods)
            {
                if (Harmony.GetPatchInfo(method)?.Transpilers.Any(patch => patch.PatchMethod == transpiler) != true)
                {
                    throw new InvalidOperationException("Dubs did not install a profiler for: " + method);
                }
            }
        }
        catch
        {
            this.Stop();
            throw;
        }
    }

    private void Stop()
    {
        if (this.ownedEntry == null)
        {
            return;
        }
        GUIController.ResetToSettings();
        GUIController.SwapToEntry("");
        MethodInfo transpiler = typeof(MethodTransplanting).GetMethod("Transpiler");
        FieldInfo patchedField = typeof(MethodTransplanting).GetField("patchedMeths",
            BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)
            ?? throw new MissingFieldException(typeof(MethodTransplanting).FullName, "patchedMeths");
        HashSet<MethodInfo> patchedMethods = (HashSet<MethodInfo>)patchedField.GetValue(null);
        foreach (MethodInfo method in this.ownedMethods)
        {
            if (MethodTransplanting.typeInfo.TryGetValue(method, out Type owner) && owner == this.ownedType)
            {
                Modbase.Harmony.Unpatch(method, transpiler);
                MethodTransplanting.typeInfo.TryRemove(method, out _);
                patchedMethods.Remove(method);
            }
        }
        if (GUIController.EntryByName(this.ownedEntry) != null)
        {
            Entry entry = GUIController.EntryByName(this.ownedEntry);
            GUIController.RemoveEntry(this.ownedEntry);
            Entry.entries.Remove(entry);
        }
        GUIController.types.Remove(this.ownedEntry);
        if (this.ownedType != null)
        {
            DynamicTypeBuilder.methods.Remove(this.ownedType.Name);
        }
        if (this.previousEntry != null)
        {
            GUIController.SwapToEntry(this.previousEntry);
        }
        DubsAnalyzer.CurrentlyPaused = this.previousPaused;
        if (!this.previousProfiling)
        {
            DubsAnalyzer.EndProfiling();
        }
        Settings.disableCleanup = this.previousDisableCleanup;
        Settings.disableThreadedPatching = this.previousDisableThreading;
        Settings.verboseLogging = this.previousVerboseLogging;
        this.ownedEntry = null;
        this.ownedMethods = null;
        this.ownedType = null;
    }

    private DubsSnapshot Snapshot(string id)
    {
        List<DubsRow> rows = new List<DubsRow>();
        int entries = Math.Min(DubsAnalyzer.GetCurrentLogCount, Profiler.RECORDS_HELD);
        lock (DubsAnalyzer.LogicLock)
        {
            foreach (Profiler profile in ProfileController.Profiles.Values)
            {
                double total = 0;
                double maximum = 0;
                long calls = 0;
                int index = ((int)profile.currentIndex + Profiler.RECORDS_HELD - 1) % Profiler.RECORDS_HELD;
                for (int cycle = 0; cycle < entries; cycle++)
                {
                    int hits = profile.hits[index];
                    if (hits > 0)
                    {
                        double elapsed = profile.times[index];
                        total += elapsed;
                        maximum = Math.Max(maximum, elapsed);
                        calls += hits;
                    }
                    index = (index + Profiler.RECORDS_HELD - 1) % Profiler.RECORDS_HELD;
                }
                if (calls == 0) continue;
                rows.Add(new DubsRow
                {
                    Key = profile.key, Label = profile.label,
                    Method = profile.meth == null ? null : profile.meth.DeclaringType?.FullName + ":" + profile.meth.Name,
                    Assembly = (profile.meth?.DeclaringType ?? profile.type)?.Assembly.GetName().Name,
                    Entries = entries, AverageMs = entries > 0 ? total / entries : 0, MaxMs = maximum,
                    TotalMs = total, Calls = calls,
                    CallsPerCycle = entries > 0 ? (double)calls / entries : 0,
                    AveragePerCallMs = total / calls
                });
            }
        }
        int pawns = 0;
        int hcfUnits = 0;
        foreach (Map map in Find.Maps)
        {
            foreach (Pawn pawn in map.mapPawns.AllPawnsSpawned)
            {
                pawns++;
                if (HiveCreatureFramework.HCFGameUtility.GetUnitComp(pawn) != null)
                {
                    hcfUnits++;
                }
            }
        }
        return new DubsSnapshot
        {
            Id = id, CapturedUtc = DateTime.UtcNow.ToString("O"),
            DubsVersion = typeof(Modbase).Assembly.GetName().Version.ToString(),
            Category = GUIController.CurrentCategory.ToString(), Entry = GUIController.CurrentEntry?.name,
            Profiling = DubsAnalyzer.CurrentlyProfiling, Paused = DubsAnalyzer.CurrentlyPaused,
            GamePaused = Find.TickManager.Paused, TicksGame = Find.TickManager.TicksGame,
            Frames = Time.frameCount, Entries = DubsAnalyzer.GetCurrentLogCount,
            Maps = Find.Maps.Count, SpawnedPawns = pawns, SpawnedHcfUnits = hcfUnits,
            TestKind = this.scenario.Kind, TestMode = this.scenario.Mode,
            TestGroupType = this.scenario.GroupType, TestGroupCount = this.scenario.GroupCount,
            ProbeCallsPerTick = this.scenario.ProbeCallsPerTick,
            ShowTargets = HiveCreatureFramework.GameComponent_UnitGroup.Instance.showHiveGroupTargets,
            BaselineGroupLayout = DubsGroupLayoutBaseline.Enabled, CompareProbe = this.scenario.CompareProbe,
            Verification = this.scenario.Verification,
            HiveCount = this.scenario.HiveScenario.HiveCount,
            StoredUnits = this.scenario.HiveScenario.StoredUnits,
            InjuredUnits = this.scenario.HiveScenario.InjuredUnits,
            ProgressCount = this.scenario.HiveScenario.ProgressCount,
            DeveloperMode = Prefs.DevMode,
            DeveloperLogs = HiveCreatureFramework.HCFMod.Settings.developerLogs,
            BaselineTargetSearch = DubsTargetSearchBaseline.Enabled,
            TargetVerification = this.scenario.TargetVerification,
            Rows = rows.OrderByDescending(row => row.AverageMs).ToArray()
        };
    }

    private void WriteSnapshot(string directory, DubsSnapshot snapshot)
    {
        Directory.CreateDirectory(directory);
        string path = Path.Combine(directory, "response.json");
        string temporary = path + ".tmp";
        using (FileStream stream = File.Create(temporary))
        {
            new DataContractJsonSerializer(typeof(DubsSnapshot)).WriteObject(stream, snapshot);
        }
        if (File.Exists(path))
        {
            File.Replace(temporary, path, null);
        }
        else
        {
            File.Move(temporary, path);
        }
    }

    private float nextPoll;
    private string lastRequestId;
    private string ownedEntry;
    private HashSet<MethodInfo> ownedMethods;
    private Type ownedType;
    private string previousEntry;
    private bool previousPaused;
    private bool previousProfiling;
    private bool previousDisableCleanup;
    private bool previousDisableThreading;
    private bool previousVerboseLogging;
    private DubsTestScenario scenario = new DubsTestScenario();
}
