using System.Runtime.Serialization;

namespace CQF.PerformanceBridge;

[DataContract]
public sealed class DubsRow
{
    [DataMember] public string Key { get; set; }
    [DataMember] public string Label { get; set; }
    [DataMember] public string Method { get; set; }
    [DataMember] public string Assembly { get; set; }
    [DataMember] public int Entries { get; set; }
    [DataMember] public double AverageMs { get; set; }
    [DataMember] public double MaxMs { get; set; }
    [DataMember] public double TotalMs { get; set; }
    [DataMember] public double Calls { get; set; }
    [DataMember] public double CallsPerCycle { get; set; }
    [DataMember] public double AveragePerCallMs { get; set; }
}
