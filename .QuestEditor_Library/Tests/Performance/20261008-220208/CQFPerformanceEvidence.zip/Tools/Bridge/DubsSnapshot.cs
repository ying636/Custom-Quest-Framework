using System.Runtime.Serialization;

namespace CQF.PerformanceBridge;

[DataContract]
public sealed class DubsSnapshot
{
    [DataMember] public string Id { get; set; }
    [DataMember] public string Error { get; set; }
    [DataMember] public string CapturedUtc { get; set; }
    [DataMember] public string DubsVersion { get; set; }
    [DataMember] public string Category { get; set; }
    [DataMember] public string Entry { get; set; }
    [DataMember] public bool Profiling { get; set; }
    [DataMember] public bool Paused { get; set; }
    [DataMember] public bool GamePaused { get; set; }
    [DataMember] public int TicksGame { get; set; }
    [DataMember] public int Frames { get; set; }
    [DataMember] public int Entries { get; set; }
    [DataMember] public int Maps { get; set; }
    [DataMember] public int SpawnedPawns { get; set; }
    [DataMember] public int SpawnedHcfUnits { get; set; }
    [DataMember] public string TestKind { get; set; }
    [DataMember] public string TestMode { get; set; }
    [DataMember] public string TestGroupType { get; set; }
    [DataMember] public int TestGroupCount { get; set; }
    [DataMember] public int ProbeCallsPerTick { get; set; }
    [DataMember] public bool ShowTargets { get; set; }
    [DataMember] public bool BaselineGroupLayout { get; set; }
    [DataMember] public bool CompareProbe { get; set; }
    [DataMember] public DubsVerification Verification { get; set; }
    [DataMember] public int HiveCount { get; set; }
    [DataMember] public int StoredUnits { get; set; }
    [DataMember] public int InjuredUnits { get; set; }
    [DataMember] public int ProgressCount { get; set; }
    [DataMember] public bool DeveloperMode { get; set; }
    [DataMember] public bool DeveloperLogs { get; set; }
    [DataMember] public bool BaselineTargetSearch { get; set; }
    [DataMember] public DubsTargetVerification TargetVerification { get; set; }
    [DataMember] public DubsRow[] Rows { get; set; }
}
