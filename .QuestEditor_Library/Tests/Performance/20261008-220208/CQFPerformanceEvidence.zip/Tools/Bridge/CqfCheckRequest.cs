using System;
using QuestEditor_Library;

namespace CQF.PerformanceBridge;

public sealed class CqfCheckRequest : ExecutiveRequest
{
    public CqfCheckRequest(int delay, Action execute)
    {
        this.delayTime = delay;
        this.execute = execute;
    }

    public override void Execute()
    {
        this.execute();
    }

    private readonly Action execute;
}
