using System.Runtime.Serialization;

namespace CQF.PerformanceBridge;

[DataContract]
public sealed class DubsRequest
{
    [DataMember] public string Id { get; set; }
    [DataMember] public string Action { get; set; }
    [DataMember] public string Cycle { get; set; }
    [DataMember] public string[] Methods { get; set; }
    [DataMember] public string Kind { get; set; }
    [DataMember] public string Mode { get; set; }
    [DataMember] public int Count { get; set; }
    [DataMember] public int GroupCount { get; set; }
    [DataMember] public bool ShowTargets { get; set; }
    [DataMember] public string GroupType { get; set; }
    [DataMember] public int ProbeCallsPerTick { get; set; }
    [DataMember] public bool BaselineGroupLayout { get; set; }
    [DataMember] public bool CompareProbe { get; set; }
    [DataMember] public int HiveCount { get; set; }
    [DataMember] public bool StoreUnits { get; set; }
    [DataMember] public bool InjuredUnits { get; set; }
    [DataMember] public bool HealUnits { get; set; }
    [DataMember] public bool DepletedMaintenance { get; set; }
    [DataMember] public int ProgressPerHive { get; set; }
    [DataMember] public int HaulStacks { get; set; }
    [DataMember] public bool DeveloperMode { get; set; }
    [DataMember] public bool DeveloperLogs { get; set; }
    [DataMember] public bool BaselineTargetSearch { get; set; }
    [DataMember] public bool BaselineCqfTick { get; set; }
}
