using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using QuestEditor_Library;
using Verse;

namespace CQF.PerformanceBridge;

public static class CqfTickChecks
{
    public static void Run()
    {
        GameComponent_Editor component = GameComponent_Editor.Instance;
        if (!GenCommandLine.CommandLineArgPassed("quicktest") || component == null
            || component.Request.Count != 0 || component.CACDS.Count != 0)
        {
            throw new InvalidOperationException("CQF checks require an empty quicktest component.");
        }
        List<string> results = new List<string>();
        try
        {
            foreach (bool baseline in new[] { true, false })
            {
                CqfTickBaseline.SetEnabled(baseline);
                Verify(component);
                results.Add((baseline ? "baseline" : "optimized") + ": passed 9 checks");
            }
        }
        finally
        {
            component.Request.Clear();
            component.CACDS.Clear();
            CqfTickBaseline.SetEnabled(false);
        }
        string resultPath = Path.Combine(GenFilePaths.SaveDataFolderPath, "CQFVerification.txt");
        File.WriteAllLines(resultPath, results);
        Log.Message("CQF_Performance_Verified: " + string.Join("; ", results));
    }

    private static void Verify(GameComponent_Editor component)
    {
        List<string> events = new List<string>();
        component.GameComponentTick();
        Require(component.Request.Count == 0 && component.CACDS.Count == 0, "empty tick");
        CqfCheckRequest deferred = new CqfCheckRequest(2, () => events.Add("D"));
        component.AddExecutiveRequest(new CqfCheckRequest(1, () =>
        {
            events.Add("A");
            component.AddExecutiveRequest(new CqfCheckRequest(1, () => events.Add("C")));
        }));
        component.AddExecutiveRequest(new CqfCheckRequest(1, () => events.Add("B")));
        component.AddExecutiveRequest(deferred);
        component.GameComponentTick();
        Require(events.SequenceEqual(new[] { "A", "B" }), "request execution order");
        Require(deferred.delayTime == 1, "delay decrement");
        Require(component.Request.Count == 2, "reentrant enqueue remains pending");
        component.GameComponentTick();
        Require(events.SequenceEqual(new[] { "A", "B", "D", "C" }) && component.Request.Count == 0, "next tick execution");
        component.AddExecutiveRequest(new CqfCheckRequest(0, () => events.Add("zero")));
        component.AddExecutiveRequest(new CqfCheckRequest(-2, () => events.Add("negative")));
        component.GameComponentTick();
        Require(events.Skip(4).SequenceEqual(new[] { "zero", "negative" }), "nonpositive delays");
        CaravanActionDef expired = new CaravanActionDef { defName = "CQF_Performance_Expired" };
        CaravanActionDef pending = new CaravanActionDef { defName = "CQF_Performance_Pending" };
        component.CACDS.Add(expired, new CD { curTick = Find.TickManager.TicksGame, time = 0 });
        component.CACDS.Add(pending, new CD { curTick = Find.TickManager.TicksGame, time = 10 });
        component.GameComponentTick();
        Require(!component.CACDS.ContainsKey(expired) && component.CACDS.ContainsKey(pending), "cooldowns without requests");
        component.CACDS[pending].curTick -= 10;
        component.GameComponentTick();
        Require(component.CACDS.Count == 0, "cooldown boundary");
        int before = events.Count;
        component.GameComponentTick();
        Require(events.Count == before && component.Request.Count == 0, "empty after completion");
    }

    private static void Require(bool condition, string name)
    {
        if (!condition)
        {
            throw new InvalidOperationException("CQF check failed: " + name);
        }
    }
}
