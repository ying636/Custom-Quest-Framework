using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using HiveCreatureFramework;
using RimWorld;
using Verse;
using Verse.AI;

namespace CQF.PerformanceBridge;

public static class DubsTargetSearchVerification
{
    public static DubsTargetVerification Verify(List<Pawn> ownedPawns)
    {
        if (!GenCommandLine.CommandLineArgPassed("quicktest") || Find.CurrentMap == null)
            throw new InvalidOperationException("Target verification requires a quicktest map.");
        Map map = Find.CurrentMap;
        List<Pawn> pawns = ownedPawns.Where(pawn => pawn.Spawned && !pawn.Dead && !pawn.Downed)
            .OrderBy(pawn => pawn.Position.DistanceToSquared(map.Center)).Take(12).ToList();
        if (pawns.Count == 0) throw new InvalidOperationException("Target verification requires spawned test units.");
        Faction hostileFaction = Find.FactionManager.AllFactionsListForReading
            .FirstOrDefault(faction => faction.HostileTo(Faction.OfPlayer))
            ?? throw new InvalidOperationException("No hostile faction exists.");
        List<string> cases = new List<string>();
        DubsTargetVerification result = new DubsTargetVerification();
        TimeSpeed speed = Find.TickManager.CurTimeSpeed;
        bool baseline = DubsTargetSearchBaseline.Enabled;
        Pawn enemy = null;
        Find.TickManager.Pause();
        try
        {
            CheckSearch(pawns, "no-injected-enemy", result, cases);
            enemy = PawnGenerator.GeneratePawn(pawns[0].kindDef, hostileFaction);
            IntVec3 near = GenRadial.RadialCellsAround(pawns[0].Position, 8f, true)
                .First(cell => cell.InBounds(map) && cell.Standable(map) && !cell.Fogged(map));
            GenSpawn.Spawn(enemy, near, map);
            CheckSearch(pawns, "enemy-spawned", result, cases);
            CheckIssue(pawns, enemy, true, false, result);
            CheckIssue(pawns, enemy, false, true, result);
            enemy.DeSpawn();
            CheckSearch(pawns, "enemy-despawned", result, cases);
            IntVec3 far = map.AllCells.First(cell => cell.Standable(map)
                && cell.DistanceToSquared(pawns[0].Position) > 14400);
            GenSpawn.Spawn(enemy, far, map);
            CheckSearch(pawns, "enemy-outside-radius", result, cases);
            enemy.DeSpawn();
            GenSpawn.Spawn(enemy, near, map);
            enemy.SetFaction(Faction.OfPlayer);
            CheckSearch(pawns, "enemy-became-friendly", result, cases);
            enemy.SetFaction(null);
            if (!enemy.mindState.mentalStateHandler.TryStartMentalState(MentalStateDefOf.Manhunter,
                    forced: true, forceWake: true, transitionSilently: true))
                throw new InvalidOperationException("Test unit could not enter the manhunter state.");
            CheckSearch(pawns, "factionless-manhunter", result, cases);
            enemy.mindState.mentalStateHandler.Reset();
            enemy.SetFaction(hostileFaction);
            enemy.Destroy();
            CheckSearch(pawns, "enemy-destroyed", result, cases);
            if (result.SelectedTargets == 0)
                throw new InvalidOperationException("Verification never selected a target; positive cases were not exercised.");
            result.CaseNames = cases.Concat(new[] { "focused-target", "retained-target" }).ToArray();
            result.SettingsCases = DubsSettingsVerification.Verify();
            result.AttackTargetFinderPatchOwners = Harmony.GetPatchInfo(AccessTools.Method(
                typeof(AttackTargetFinder), nameof(AttackTargetFinder.BestAttackTarget)))?.Owners.ToArray()
                ?? Array.Empty<string>();
            return result;
        }
        finally
        {
            if (enemy != null && !enemy.Destroyed) enemy.Destroy();
            DubsTargetSearchBaseline.Enabled = baseline;
            Find.TickManager.CurTimeSpeed = speed;
        }
    }

    private static void CheckSearch(List<Pawn> pawns, string name, DubsTargetVerification result, List<string> cases)
    {
        foreach (float radius in new[] { 0f, 3f, 12f, 36f, 80f })
        {
            ThinkNode_GroupAcquireAttackTarget node = new ThinkNode_GroupAcquireAttackTarget { targetAcquireRadius = radius };
            Func<Pawn, Thing> find = (Func<Pawn, Thing>)Delegate.CreateDelegate(typeof(Func<Pawn, Thing>), node,
                typeof(ThinkNode_GroupAcquireAttackTarget).GetMethod("FindTarget", BindingFlags.NonPublic | BindingFlags.Instance));
            foreach (Pawn pawn in pawns)
            {
                DubsTargetSearchBaseline.Enabled = true;
                Thing expected;
                Rand.PushState(72941);
                try { expected = find(pawn); }
                finally { Rand.PopState(); }
                DubsTargetSearchBaseline.Enabled = false;
                Thing actual;
                Rand.PushState(72941);
                try { actual = find(pawn); }
                finally { Rand.PopState(); }
                if (actual != expected)
                    throw new InvalidOperationException("Target mismatch: " + name + ", radius=" + radius + ", pawn=" + pawn
                        + ", expected=" + expected + ", actual=" + actual);
                result.SearchCases++;
                if (actual != null) result.SelectedTargets++;
            }
        }
        cases.Add(name);
    }

    private static void CheckIssue(List<Pawn> pawns, Pawn enemy, bool focused, bool retained, DubsTargetVerification result)
    {
        ThinkNode_GroupAcquireAttackTarget node = new ThinkNode_GroupAcquireAttackTarget { targetAcquireRadius = 0f };
        foreach (Pawn pawn in pawns)
        {
            if (!JobGiver_UnitCombat.IsValidTarget(pawn, enemy)) continue;
            PawnDuty originalDuty = pawn.mindState.duty;
            Thing originalTarget = pawn.mindState.enemyTarget;
            try
            {
                pawn.mindState.duty = new PawnDuty { focus = focused ? new LocalTargetInfo(enemy) : LocalTargetInfo.Invalid };
                pawn.mindState.enemyTarget = retained ? enemy : null;
                DubsTargetSearchBaseline.Enabled = true;
                node.TryIssueJobPackage(pawn, default);
                Thing expected = pawn.mindState.enemyTarget;
                pawn.mindState.enemyTarget = retained ? enemy : null;
                DubsTargetSearchBaseline.Enabled = false;
                node.TryIssueJobPackage(pawn, default);
                if (pawn.mindState.enemyTarget != expected || expected != enemy)
                    throw new InvalidOperationException("Focused or retained target changed for " + pawn);
                result.IssueCases++;
            }
            finally
            {
                pawn.mindState.duty = originalDuty;
                pawn.mindState.enemyTarget = originalTarget;
            }
        }
    }
}
