using System;
using System.Reflection;
using System.Reflection.Emit;
using HiveCreatureFramework;

namespace CQF.PerformanceBridge;

public static class DubsSelfTargetGroupFactory
{
    public static Type Create()
    {
        if (groupType != null) return groupType;
        AssemblyBuilder assembly = AppDomain.CurrentDomain.DefineDynamicAssembly(
            new AssemblyName("HCF.DubsGroupVerification"), AssemblyBuilderAccess.Run);
        TypeBuilder type = assembly.DefineDynamicModule("HCF.DubsGroupVerification").DefineType(
            "CQF.PerformanceBridge.DubsSelfTargetGroup", TypeAttributes.Public | TypeAttributes.Sealed, typeof(UnitGroup));
        type.DefineDefaultConstructor(MethodAttributes.Public);
        MethodBuilder method = type.DefineMethod(nameof(UnitGroup.SharesTargetCellWith),
            MethodAttributes.Public | MethodAttributes.Virtual | MethodAttributes.HideBySig,
            typeof(bool), new[] { typeof(UnitGroup) });
        ILGenerator body = method.GetILGenerator();
        body.Emit(OpCodes.Ldarg_0);
        body.Emit(OpCodes.Ldarg_1);
        body.Emit(OpCodes.Ceq);
        body.Emit(OpCodes.Ret);
        type.DefineMethodOverride(method, typeof(UnitGroup).GetMethod(nameof(UnitGroup.SharesTargetCellWith), new[] { typeof(UnitGroup) }));
        groupType = type.CreateType();
        return groupType;
    }

    private static Type groupType;
}
