using System;
using HarmonyLib;
using HiveCreatureFramework;

namespace CQF.PerformanceBridge;

[HarmonyPatch(typeof(GameComponent_UnitGroup), "UsesDefaultTargetCellComparison")]
public static class DubsGroupLayoutBaseline
{
    [HarmonyPrefix]
    public static bool Prefix(Type groupType, ref bool __result)
    {
        if (!Enabled) return true;
        __result = groupType == typeof(UnitGroup);
        return false;
    }

    public static bool Enabled;
}
