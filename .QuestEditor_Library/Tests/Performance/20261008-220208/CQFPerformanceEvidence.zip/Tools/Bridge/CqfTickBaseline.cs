using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using Analyzer.Profiling;
using HarmonyLib;
using QuestEditor_Library;
using Verse;

namespace CQF.PerformanceBridge;

public static class CqfTickBaseline
{
    public static void SetEnabled(bool enabled)
    {
        if (!GenCommandLine.CommandLineArgPassed("quicktest"))
        {
            throw new InvalidOperationException("CQF comparison requires quicktest.");
        }
        if (Analyzer.Profiling.Analyzer.CurrentlyProfiling)
        {
            throw new InvalidOperationException("Stop Dubs capture before switching CQF algorithms.");
        }
        if (enabled == installed)
        {
            return;
        }
        MethodInfo method = AccessTools.Method(typeof(GameComponent_Editor), nameof(GameComponent_Editor.GameComponentTick));
        MethodInfo transpiler = AccessTools.Method(typeof(CqfTickBaseline), nameof(Transpiler));
        if (enabled)
        {
            harmony.Patch(method, transpiler: new HarmonyMethod(transpiler));
        }
        else
        {
            harmony.Unpatch(method, transpiler);
        }
        installed = enabled;
    }

    public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
    {
        List<CodeInstruction> codes = instructions.ToList();
        MethodInfo requestGetter = AccessTools.PropertyGetter(typeof(GameComponent_Editor), nameof(GameComponent_Editor.Request));
        MethodInfo cooldownGetter = AccessTools.PropertyGetter(typeof(GameComponent_Editor), nameof(GameComponent_Editor.CACDS));
        int getterIndex = codes.FindIndex(code => code.Calls(requestGetter));
        int start = getterIndex - 1;
        if (start < 0 || start + 13 >= codes.Count
            || codes[start].opcode != OpCodes.Ldarg_0
            || !codes[start + 1].Calls(requestGetter)
            || (codes[start + 2].operand as MethodInfo)?.Name != "get_Count"
            || codes[start + 3].opcode.FlowControl != FlowControl.Cond_Branch
            || codes[start + 4].opcode != OpCodes.Ldarg_0
            || !codes[start + 5].Calls(cooldownGetter)
            || (codes[start + 6].operand as MethodInfo)?.Name != "get_Count"
            || codes[start + 7].opcode.FlowControl != FlowControl.Cond_Branch
            || codes[start + 8].opcode != OpCodes.Ldarg_0
            || codes[start + 9].opcode != OpCodes.Ldfld
            || (codes[start + 9].operand as FieldInfo)?.Name != "readyRequests"
            || (codes[start + 10].operand as MethodInfo)?.Name != "get_Count"
            || codes[start + 11].opcode.FlowControl != FlowControl.Cond_Branch
            || codes[start + 12].opcode != OpCodes.Ret
            || !codes[start + 13].labels.Contains((Label)codes[start + 3].operand)
            || !codes[start + 13].labels.Contains((Label)codes[start + 7].operand)
            || !codes[start + 13].labels.Contains((Label)codes[start + 11].operand))
        {
            throw new InvalidOperationException("CQF empty guard IL differs from the verified baseline layout: "
                + string.Join("; ", codes.Take(18).Select(code => code.ToString())));
        }
        codes.RemoveRange(start, 13);
        return codes;
    }

    private static readonly Harmony harmony = new Harmony("CQF.PerformanceComparison");
    private static bool installed;
}
