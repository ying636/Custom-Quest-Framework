using System.Runtime.Serialization;

namespace CQF.PerformanceBridge;

[DataContract]
public sealed class DubsVerification
{
    [DataMember] public int GroupPositions { get; set; }
    [DataMember] public int RangedCases { get; set; }
}
