using System;
using System.Collections.Generic;
using System.Linq;
using HiveCreatureFramework;
using RimWorld;
using UnityEngine;
using Verse;

namespace CQF.PerformanceBridge;

public sealed class DubsHiveScenario
{
    public int HiveCount => this.hives.Count;
    public int StoredUnits => this.containers.Sum(container => container.units.Count);
    public int InjuredUnits
    {
        get
        {
            int count = 0;
            foreach (CompHiveContainer container in this.containers)
            {
                for (int index = 0; index < container.units.Count; index++)
                {
                    if (container.units[index].health.hediffSet.hediffs.Any(hediff => hediff is Hediff_Injury)) count++;
                }
            }
            return count;
        }
    }
    public int ProgressCount => this.hives.Sum(hive => hive.TryGetComp<CompProgressHolder>().progresses.Count);

    public void Configure(DubsRequest request, List<Pawn> pawns)
    {
        if (request.HiveCount < 0 || request.HiveCount > 60 || request.ProgressPerHive < 0 || request.ProgressPerHive > 1000
            || request.HaulStacks < 0 || request.HaulStacks > 500)
        {
            throw new ArgumentOutOfRangeException(nameof(request.HiveCount));
        }
        if (request.StoreUnits && request.HiveCount * 20 < pawns.Count)
        {
            throw new InvalidOperationException("Test storage requires at least one hive per 20 units.");
        }
        if (this.originalDevMode == null)
        {
            this.originalDevMode = Prefs.DevMode;
            this.originalLogVerbose = Prefs.LogVerbose;
            this.originalResetOnCrash = Prefs.ResetModsConfigOnCrash;
            this.originalGodMode = DebugSettings.godMode;
        }
        Prefs.DevMode = request.DeveloperMode;
        this.ApplyControls(request);
        Map map = Find.CurrentMap;
        ThingDef definition = DefDatabase<ThingDef>.GetNamed("FH_FleshHive");
        List<IntVec3> candidates = map.AllCells.Where(cell => cell.DistanceToSquared(map.Center) < 6400
            && GenAdj.OccupiedRect(cell, Rot4.North, definition.size).All(occupied => occupied.InBounds(map)
                && occupied.Standable(map) && !occupied.GetThingList(map).Any(thing => thing is Building or Pawn))).ToList();
        foreach (IntVec3 cell in candidates)
        {
            if (this.hives.Count >= request.HiveCount) break;
            if (this.hives.Any(hive => hive.Position.DistanceToSquared(cell) < 36)) continue;
            Thing hive = ThingMaker.MakeThing(definition);
            this.hives.Add(hive);
            hive.SetFaction(Faction.OfPlayer);
            GenSpawn.Spawn(hive, cell, map);
            if (!hive.Spawned) throw new InvalidOperationException("Test hive could not spawn.");
            CompHiveContainer container = hive.TryGetComp<CompHiveContainer>()
                ?? throw new InvalidOperationException("Test hive has no container.");
            container.autoRelease = false;
            container.healUnits = request.HealUnits;
            this.containers.Add(container);
            CompProgressHolder holder = hive.TryGetComp<CompProgressHolder>();
            for (int index = 0; index < request.ProgressPerHive; index++)
            {
                holder.progresses.Add(new UnitSpawnData(DefDatabase<UnitDef>.GetNamed("FH_Unit_Fingerspike"))
                {
                    time = 1000000f, totalTime = 1000000f
                });
            }
        }
        if (this.hives.Count != request.HiveCount) throw new InvalidOperationException("Not enough cells for test hives.");
        foreach (Pawn pawn in pawns)
        {
            Need_Maintenance maintenance = pawn.GetNeed<Need_Maintenance>();
            if (maintenance != null) maintenance.CurLevel = request.DepletedMaintenance ? 0.1f * maintenance.MaxLevel : maintenance.MaxLevel;
            if (request.InjuredUnits)
            {
                BodyPartRecord part = pawn.RaceProps.body.corePart;
                pawn.health.AddHediff(HediffDefOf.Cut, part).Severity = 0.6f * part.def.GetMaxHealth(pawn);
            }
        }
        if (request.StoreUnits)
        {
            for (int index = 0; index < pawns.Count; index++)
            {
                this.containers[index / 20].AddUnit(pawns[index]);
            }
        }
        if (request.HaulStacks > 0) this.ConfigureHauling(map, request.HaulStacks);
    }

    public void Cleanup()
    {
        foreach (Thing hive in this.hives) if (!hive.Destroyed) hive.Destroy();
        this.hives.Clear();
        this.containers.Clear();
        foreach (Thing item in this.items) if (!item.Destroyed) item.Destroy();
        this.items.Clear();
        this.stockpile?.Delete(false);
        this.stockpile = null;
    }

    public void RestorePreferences()
    {
        if (this.originalDeveloperLogs != null)
        {
            HCFMod.Settings.developerLogs = this.originalDeveloperLogs.Value;
            this.originalDeveloperLogs = null;
        }
        DubsTargetSearchBaseline.Enabled = false;
        if (this.originalDevMode == null) return;
        Prefs.DevMode = this.originalDevMode.Value;
        Prefs.LogVerbose = this.originalLogVerbose;
        Prefs.ResetModsConfigOnCrash = this.originalResetOnCrash;
        DebugSettings.godMode = this.originalGodMode;
        this.originalDevMode = null;
    }

    public void ApplyControls(DubsRequest request)
    {
        if (!GenCommandLine.CommandLineArgPassed("quicktest"))
            throw new InvalidOperationException("Runtime controls require a quicktest game.");
        if (this.originalDeveloperLogs == null) this.originalDeveloperLogs = HCFMod.Settings.developerLogs;
        HCFMod.Settings.developerLogs = request.DeveloperLogs;
        DubsTargetSearchBaseline.Enabled = request.BaselineTargetSearch;
    }

    private void ConfigureHauling(Map map, int stacks)
    {
        List<IntVec3> cells = map.AllCells.Where(cell => cell.Standable(map) && cell.DistanceToSquared(map.Center) < 3600
            && !cell.GetThingList(map).Any(thing => thing is Building || !thing.def.CanOverlapZones)
            && map.zoneManager.ZoneAt(cell) == null).ToList();
        if (cells.Count < stacks + 200) throw new InvalidOperationException("Not enough hauling test cells.");
        this.stockpile = new Zone_Stockpile(StorageSettingsPreset.DefaultStockpile, map.zoneManager);
        map.zoneManager.RegisterZone(this.stockpile);
        foreach (IntVec3 cell in cells.Take(200)) this.stockpile.AddCell(cell);
        for (int index = 0; index < stacks; index++)
        {
            Thing item = ThingMaker.MakeThing(ThingDefOf.Steel);
            item.stackCount = 10;
            this.items.Add(item);
            GenSpawn.Spawn(item, cells[200 + index * (cells.Count - 200) / stacks], map);
        }
    }

    private readonly List<Thing> hives = new List<Thing>();
    private readonly List<CompHiveContainer> containers = new List<CompHiveContainer>();
    private readonly List<Thing> items = new List<Thing>();
    private Zone_Stockpile stockpile;
    private bool? originalDevMode;
    private bool originalLogVerbose;
    private bool originalResetOnCrash;
    private bool originalGodMode;
    private bool? originalDeveloperLogs;
}
