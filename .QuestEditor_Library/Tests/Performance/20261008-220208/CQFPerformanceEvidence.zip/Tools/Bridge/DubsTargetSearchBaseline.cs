using HarmonyLib;
using HiveCreatureFramework;
using Verse;
using Verse.AI;

namespace CQF.PerformanceBridge;

[HarmonyPatch(typeof(ThinkNode_GroupAcquireAttackTarget), "FindTarget")]
public static class DubsTargetSearchBaseline
{
    [HarmonyPrefix]
    public static bool Prefix(ThinkNode_GroupAcquireAttackTarget __instance, Pawn pawn, ref Thing __result)
    {
        if (!Enabled) return true;
        ModExtension_UnitSkillDuty extension = ModExtension_UnitSkillDuty.GetFor(pawn);
        float searchRadius = extension?.targetAcquireRadius >= 0f
            ? extension.targetAcquireRadius
            : __instance.targetAcquireRadius;
        __result = AttackTargetFinder.BestAttackTarget(pawn,
            TargetScanFlags.NeedLOSToPawns | TargetScanFlags.NeedReachableIfCantHitFromMyPos
            | TargetScanFlags.NeedThreat | TargetScanFlags.NeedAutoTargetable,
            candidate => JobGiver_UnitCombat.IsValidTarget(pawn, candidate),
            0f, searchRadius, pawn.Position, searchRadius)?.Thing;
        return false;
    }

    public static bool Enabled;
}
