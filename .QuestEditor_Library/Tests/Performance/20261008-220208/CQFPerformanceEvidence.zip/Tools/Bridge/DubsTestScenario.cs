using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HiveCreatureFramework;
using RimWorld;
using Verse;
using Verse.AI.Group;
using Verse.AI;
using UnityEngine;

namespace CQF.PerformanceBridge;

public sealed class DubsTestScenario
{
    public string Kind { get; private set; }
    public string Mode { get; private set; }
    public string GroupType { get; private set; }
    public int GroupCount => this.groups.Count;
    public int ProbeCallsPerTick { get; private set; }
    public bool CompareProbe { get; private set; }
    public DubsVerification Verification { get; private set; }
    public DubsTargetVerification TargetVerification { get; private set; }
    public DubsHiveScenario HiveScenario => this.hiveScenario;

    public void Configure(DubsRequest request)
    {
        if (!GenCommandLine.CommandLineArgPassed("quicktest") || Find.CurrentMap == null)
        {
            throw new InvalidOperationException("Scenario commands require a -quicktest game with a loaded map.");
        }
        if (request.Count < 0 || request.Count > 500 || request.GroupCount < 1 || request.GroupCount > 100)
        {
            throw new ArgumentOutOfRangeException(nameof(request.Count));
        }
        PawnKindDef kind = DefDatabase<PawnKindDef>.GetNamed(request.Kind);
        GroupWorkModeDef mode = DefDatabase<GroupWorkModeDef>.GetNamed(request.Mode);
        Type groupType = string.IsNullOrEmpty(request.GroupType) ? typeof(UnitGroup)
            : AppDomain.CurrentDomain.GetAssemblies().Select(assembly => assembly.GetType(request.GroupType, false))
                .FirstOrDefault(type => type != null) ?? throw new TypeLoadException(request.GroupType);
        if (!typeof(UnitGroup).IsAssignableFrom(groupType) || groupType.IsAbstract
            || request.ProbeCallsPerTick < 0 || request.ProbeCallsPerTick > 10)
        {
            throw new InvalidOperationException("Invalid test group type or probe count.");
        }
        Map map = Find.CurrentMap;
        Find.TickManager.Pause();
        this.ProbeCallsPerTick = 0;
        this.Verification = null;
        this.TargetVerification = null;
        DubsGroupLayoutBaseline.Enabled = request.BaselineGroupLayout;
        foreach (Pawn pawn in this.pawns)
        {
            HCFGameUtility.GetUnitComp(pawn)?.group?.RemoveUnit(pawn);
            pawn.holdingOwner?.Remove(pawn);
            if (!pawn.Destroyed) pawn.Destroy();
        }
        this.pawns.Clear();
        foreach (UnitGroup group in this.groups) group.Destroy();
        this.groups.Clear();
        this.hiveScenario.Cleanup();
        List<IntVec3> cells = map.AllCells.Where(cell => cell.Standable(map)
            && !cell.GetThingList(map).Any(thing => thing is Building)
            && cell.DistanceToSquared(map.Center) < 1600).ToList();
        if (cells.Count < request.Count)
        {
            throw new InvalidOperationException("Not enough walkable test cells.");
        }
        for (int index = 0; index < request.GroupCount; index++)
        {
            UnitGroup group = GameComponent_UnitGroup.Instance.MakeNewGroup(groupType);
            group.map = map;
            group.unitLimit = 10000;
            group.tags.Add("Flesh");
            group.autoReturnHive = false;
            group.SetTarget(new TargetInfo(map.Center, map), false);
            group.workModeDef = mode;
            group.lord = LordMaker.MakeNewLord(Faction.OfPlayer, new LordJob_HiveGroup(group), map);
            group.Spawn(map);
            this.groups.Add(group);
        }
        for (int index = 0; index < request.Count; index++)
        {
            Pawn pawn = PawnGenerator.GeneratePawn(kind, Faction.OfPlayer);
            if (HCFGameUtility.GetUnitComp(pawn) == null)
            {
                throw new InvalidOperationException("Test kind has no UnitComp: " + request.Kind);
            }
            GenSpawn.Spawn(pawn, cells[index * cells.Count / Math.Max(1, request.Count)], map);
            this.groups[index % this.groups.Count].AcceptUnit(pawn);
            this.pawns.Add(pawn);
        }
        GameComponent_UnitGroup.Instance.showHiveGroupTargets = request.ShowTargets;
        this.Kind = request.Kind;
        this.Mode = request.Mode;
        this.GroupType = groupType.FullName;
        this.probeTarget = map.mapPawns.FreeColonistsSpawned.FirstOrDefault()
            ?? throw new InvalidOperationException("Test map has no colonist for the position probe.");
        this.positionFinder = (RangedPositionFinder)Delegate.CreateDelegate(typeof(RangedPositionFinder),
            typeof(JobGiver_UnitCombat).GetMethod("TryFindRangedPosition", BindingFlags.NonPublic | BindingFlags.Static));
        this.ProbeCallsPerTick = request.ProbeCallsPerTick;
        this.CompareProbe = request.CompareProbe;
        this.hiveScenario.Configure(request, this.pawns);
        Find.TickManager.CurTimeSpeed = TimeSpeed.Normal;
    }

    public void Tick()
    {
        if (this.ProbeCallsPerTick == 0) return;
        if (this.pawns.Count == 0 || !this.probeTarget.Spawned)
        {
            this.ProbeCallsPerTick = 0;
            throw new InvalidOperationException("Position probe lost its pawn or target.");
        }
        for (int index = 0; index < this.ProbeCallsPerTick; index++)
        {
            Pawn pawn = this.pawns[this.probeIndex++ % this.pawns.Count];
            if (!pawn.Spawned || pawn.Dead) throw new InvalidOperationException("Position probe pawn is unavailable.");
            bool baselineFirst = this.CompareProbe && (this.probeIndex & 1) == 0;
            if (baselineFirst)
            {
                DubsBaselineRangedPosition.TryFindRangedPosition(pawn, this.probeTarget, 15f, 18.9f, false, true, false, false, out _);
            }
            this.positionFinder(pawn, this.probeTarget, 15f, 18.9f, false, true, false, false, out _);
            if (this.CompareProbe && !baselineFirst)
            {
                DubsBaselineRangedPosition.TryFindRangedPosition(pawn, this.probeTarget, 15f, 18.9f, false, true, false, false, out _);
            }
        }
    }

    public void Verify()
    {
        if (!GenCommandLine.CommandLineArgPassed("quicktest") || Find.CurrentMap == null)
        {
            throw new InvalidOperationException("Verification requires a quicktest map.");
        }
        GameComponent_UnitGroup component = GameComponent_UnitGroup.Instance;
        TimeSpeed speed = Find.TickManager.CurTimeSpeed;
        bool baseline = DubsGroupLayoutBaseline.Enabled;
        bool thumbnails = component.showGroupThumbnails;
        Find.TickManager.Pause();
        DubsGroupLayoutBaseline.Enabled = false;
        DubsVerification result = new DubsVerification();
        List<UnitGroup> temporaryGroups = new List<UnitGroup>();
        try
        {
            foreach (Type type in new[] { typeof(UnitGroup), DubsSelfTargetGroupFactory.Create() })
            {
                UnitGroup group = component.MakeNewGroup(type);
                temporaryGroups.Add(group);
                group.map = Find.CurrentMap;
                group.SetTarget(new TargetInfo(Find.CurrentMap.Center, Find.CurrentMap), false);
            }
            MethodInfo prepare = typeof(GameComponent_UnitGroup).GetMethod("PrepareTargetDrawPositions", BindingFlags.NonPublic | BindingFlags.Instance);
            MethodInfo uncached = typeof(GameComponent_UnitGroup).GetMethod("GetUncachedTargetDrawPos", BindingFlags.NonPublic | BindingFlags.Instance);
            FieldInfo cacheActive = typeof(GameComponent_UnitGroup).GetField("targetDrawCacheActive", BindingFlags.NonPublic | BindingFlags.Instance);
            foreach (bool useThumbnails in new[] { false, true })
            {
                component.showGroupThumbnails = useThumbnails;
                prepare.Invoke(component, null);
                try
                {
                    foreach (UnitGroup group in component.groups)
                    {
                        if (!group.CanDrawTarget || !group.Show || group.BaseDrawPos == default) continue;
                        Vector3 expected = (Vector3)uncached.Invoke(component, new object[] { group });
                        Vector3 actual = component.GetTargetDrawPos(group);
                        if ((actual - expected).sqrMagnitude > 0.00000001f)
                        {
                            throw new InvalidOperationException("Group layout mismatch: " + group.GetType().FullName);
                        }
                        result.GroupPositions++;
                    }
                }
                finally
                {
                    cacheActive.SetValue(component, false);
                }
            }
            Thing[] targets = new[] { this.probeTarget }.Concat(this.pawns.Take(2).Cast<Thing>()).ToArray();
            foreach (Pawn pawn in this.pawns)
            {
                PawnDuty originalDuty = pawn.mindState.duty;
                try
                {
                    pawn.mindState.duty = new PawnDuty { focus = pawn.Position, radius = 8f };
                    foreach (Thing target in targets)
                    {
                        foreach (float maximum in new[] { 3.8f, 14f, 18.9f })
                        {
                            float minimum = maximum == 3.8f ? 0f : maximum == 14f ? 10f : 15f;
                            for (int flags = 0; flags < 16; flags++)
                            {
                                bool forceMove = (flags & 1) != 0;
                                bool seekCover = (flags & 2) != 0;
                                bool respectDutyArea = (flags & 4) != 0;
                                bool requireCover = (flags & 8) != 0;
                                bool expected = DubsBaselineRangedPosition.TryFindRangedPosition(pawn, target, minimum, maximum,
                                    forceMove, seekCover, respectDutyArea, requireCover, out IntVec3 expectedCell);
                                bool actual = this.positionFinder(pawn, target, minimum, maximum,
                                    forceMove, seekCover, respectDutyArea, requireCover, out IntVec3 actualCell);
                                if (actual != expected || actualCell != expectedCell)
                                {
                                    throw new InvalidOperationException("Ranged position mismatch: " + pawn + ", flags=" + flags
                                        + ", range=" + maximum + ", expected=" + expectedCell + ", actual=" + actualCell);
                                }
                                result.RangedCases++;
                            }
                        }
                    }
                }
                finally
                {
                    pawn.mindState.duty = originalDuty;
                }
            }
            this.Verification = result;
        }
        finally
        {
            foreach (UnitGroup group in temporaryGroups) group.Destroy();
            component.showGroupThumbnails = thumbnails;
            DubsGroupLayoutBaseline.Enabled = baseline;
            Find.TickManager.CurTimeSpeed = speed;
        }
    }

    public void VerifyTargets()
    {
        this.TargetVerification = DubsTargetSearchVerification.Verify(this.pawns);
    }

    private delegate bool RangedPositionFinder(Pawn pawn, Thing target, float minimumRange, float maximumRange,
        bool forceMove, bool seekCover, bool respectDutyArea, bool requireCover, out IntVec3 rangedPosition);

    private List<Pawn> pawns = new List<Pawn>();
    private List<UnitGroup> groups = new List<UnitGroup>();
    private Thing probeTarget;
    private RangedPositionFinder positionFinder;
    private int probeIndex;
    private DubsHiveScenario hiveScenario = new DubsHiveScenario();
}
