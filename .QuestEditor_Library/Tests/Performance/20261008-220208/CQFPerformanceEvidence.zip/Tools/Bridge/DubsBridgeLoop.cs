using HarmonyLib;
using Verse;

namespace CQF.PerformanceBridge;

[StaticConstructorOnStartup]
[HarmonyPatch(typeof(Root_Play), "Update")]
public static class DubsBridgeLoop
{
    static DubsBridgeLoop()
    {
        new Harmony("CQF.PerformanceBridge").PatchAll(typeof(DubsBridgeLoop).Assembly);
    }

    [HarmonyPostfix]
    [HarmonyAfter("Dubwise.DubsProfiler")]
    public static void Postfix()
    {
        if (Current.ProgramState == ProgramState.Playing)
        {
            Current.Game?.GetComponent<GameComponent_DubsReader>()?.Poll();
        }
    }
}
