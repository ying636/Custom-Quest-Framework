using System;
using System.IO;
using HiveCreatureFramework;
using UnityEngine;
using Verse;

namespace CQF.PerformanceBridge;

public static class DubsSettingsVerification
{
    public static int Verify()
    {
        if (Scribe.mode != LoadSaveMode.Inactive)
            throw new InvalidOperationException("Settings verification requires inactive Scribe.");
        if (new HCFSettings().developerLogs)
            throw new InvalidOperationException("Developer logging is enabled by default.");
        string directory = Path.Combine(GenFilePaths.SaveDataFolderPath, "CQF-DubsBridge");
        Directory.CreateDirectory(directory);
        int cases = 0;
        foreach (bool enabled in new[] { false, true })
        {
            string path = Path.Combine(directory, "settings-roundtrip-" + enabled + ".xml");
            HCFSettings settings = new HCFSettings { developerLogs = enabled };
            settings.SetHiveGroupShortcut(KeyCode.F7);
            settings.SetHiveBuildingShortcut(KeyCode.F8);
            try
            {
                Scribe.saver.InitSaving(path, "HCF_SettingsTest");
                Scribe_Deep.Look(ref settings, "settings");
                Scribe.saver.FinalizeSaving();
                HCFSettings loaded = null;
                Scribe.loader.InitLoading(path);
                Scribe_Deep.Look(ref loaded, "settings");
                Scribe.loader.FinalizeLoading();
                if (loaded == null || loaded.developerLogs != enabled || loaded.HiveGroupShortcut != KeyCode.F7
                    || loaded.HiveBuildingShortcut != KeyCode.F8)
                    throw new InvalidOperationException("Settings serialization mismatch, developerLogs=" + enabled);
                cases++;
            }
            finally
            {
                if (Scribe.mode != LoadSaveMode.Inactive) Scribe.ForceStop();
            }
        }
        return cases;
    }
}
