using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace CQF.PerformanceBridge;

public static class DubsBaselineRangedPosition
{
    public static bool TryFindRangedPosition(Pawn pawn, Thing target, float minimumRange, float maximumRange,
        bool forceMove, bool seekCover, bool respectDutyArea, bool requireCover, out IntVec3 rangedPosition)
    {
        rangedPosition = IntVec3.Invalid;
        int bestDistanceToPawn = int.MaxValue;
        float bestPositionPreference = float.MinValue;
        IntVec3 firstValidPosition = IntVec3.Invalid;
        IntVec3 searchCenter = forceMove ? pawn.Position : target.Position;
        float searchRadius = forceMove ? MoveAfterAttackSearchRadius : maximumRange;
        foreach (IntVec3 cell in GenRadial.RadialCellsAround(searchCenter, searchRadius, !forceMove))
        {
            float distanceToTarget = cell.DistanceTo(target.Position);
            if (!cell.InBounds(pawn.Map)
                || !cell.Standable(pawn.Map)
                || distanceToTarget < minimumRange
                || distanceToTarget > maximumRange
                || (forceMove && cell == pawn.Position)
                || (respectDutyArea && !IsWithinDutyArea(pawn, cell))
                || !pawn.CanReach(cell, PathEndMode.OnCell, Danger.Deadly))
            {
                continue;
            }

            if (forceMove)
            {
                if (!firstValidPosition.IsValid)
                {
                    firstValidPosition = cell;
                }

                if (!seekCover)
                {
                    rangedPosition = cell;
                    return true;
                }

                if (CoverUtility.CalculateOverallBlockChance(cell, target.Position, pawn.Map) > 0.01f)
                {
                    rangedPosition = cell;
                    return true;
                }

                continue;
            }

            float coverChance = seekCover || requireCover
                ? CoverUtility.CalculateOverallBlockChance(cell, target.Position, pawn.Map)
                : 0f;
            if (requireCover && coverChance <= 0.01f)
            {
                continue;
            }

            float positionPreference = seekCover ? coverChance * CoverPreferenceFactor : 0f;
            int distanceToPawn = pawn.Position.DistanceToSquared(cell);
            positionPreference += Mathf.Pow(DistancePreferenceFactor, Mathf.Sqrt(distanceToPawn));
            if (positionPreference < bestPositionPreference
                || (Mathf.Approximately(positionPreference, bestPositionPreference)
                    && distanceToPawn >= bestDistanceToPawn))
            {
                continue;
            }

            bestPositionPreference = positionPreference;
            bestDistanceToPawn = distanceToPawn;
            rangedPosition = cell;
        }

        if (forceMove && firstValidPosition.IsValid)
        {
            rangedPosition = firstValidPosition;
        }

        return rangedPosition.IsValid;
    }

    private static bool IsWithinDutyArea(Pawn pawn, IntVec3 cell)
    {
        PawnDuty duty = pawn.mindState?.duty;
        if (duty == null || duty.radius < 0f || duty.focus.Thing != null)
        {
            return true;
        }

        IntVec3 dutyLocation = duty.focus.Cell;
        return dutyLocation.IsValid && cell.InHorDistOf(dutyLocation, duty.radius);
    }

    private const float MoveAfterAttackSearchRadius = 5f;
    private const float CoverPreferenceFactor = 0.55f;
    private const float DistancePreferenceFactor = 0.967f;
}
