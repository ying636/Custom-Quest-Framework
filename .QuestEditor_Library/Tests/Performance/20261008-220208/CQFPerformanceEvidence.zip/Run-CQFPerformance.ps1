param(
    [string]$SaveDataPath = 'C:\Users\HaiLu\AppData\Local\Temp\CQFPerformance-20261008-220208',
    [string]$OutputDirectory = (Join-Path $PSScriptRoot 'Results\Comparison'),
    [int]$Seconds = 12
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$captureScript = Join-Path $PSScriptRoot 'Tools\Invoke-DubsCapture.ps1'
$captureArguments = @{
    SaveDataPath = $SaveDataPath
    ModRoot = 'D:\Game\Steam\steamapps\common\RimWorld\Mods\CQF'
    TimeoutSeconds = 60
}

try {
    & $captureScript -Action VerifyCqf @captureArguments | Out-Null
    foreach ($unitCount in @(0, 100, 400)) {
        $scenario = & $captureScript -Action Scenario -Count $unitCount -GroupCount 10 -ShowTargets $false @captureArguments
        if ($scenario.SpawnedHcfUnits -ne $unitCount) { throw "Unexpected unit count: $($scenario.SpawnedHcfUnits)" }
        foreach ($round in 1..3) {
            $order = if ($round % 2 -eq 1) { @($true, $false) } else { @($false, $true) }
            foreach ($baseline in $order) {
                $variant = if ($baseline) { 'Baseline' } else { 'Optimized' }
                & $captureScript -Action Tuning -BaselineCqfTick $baseline @captureArguments | Out-Null
                Write-Host "CQF comparison: units=$unitCount round=$round variant=$variant"
                & $captureScript -Action Capture -Cycle Tick -Seconds $Seconds -WarmupSeconds 2 -OutputDirectory (Join-Path $OutputDirectory "$unitCount\$round\$variant") -Methods @('QuestEditor_Library.GameComponent_Editor:GameComponentTick') @captureArguments
            }
        }
    }
    & $captureScript -Action VerifyCqf @captureArguments | Out-Null
} finally {
    & $captureScript -Action Restore @captureArguments | Out-Null
}
